package artists.gallery.bsd.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtistsGalleryApplicationTests {

	@Test
	void contextLoads() {
	}

}
